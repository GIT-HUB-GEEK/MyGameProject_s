""

def init():
    glClearColor(0, 0, 0, 1)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(-W_Width // 2, W_Width // 2, -W_Height // 2, W_Height // 2, -1, 1)
    for i in range(100):
        stars.append((random.randint(-W_Width // 2, W_Width // 2), random.randint(-W_Height // 2, W_Height // 2)))
    for j in range(50):
        rain_drops.append((random.randint(-W_Width // 2, W_Width // 2), random.randint(-W_Height // 2, W_Height // 2)))

glutInit()
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
glutInitWindowSize(W_Width, W_Height)
glutCreateWindow(b"Space Escape")
init()
glutDisplayFunc(display)
glutKeyboardFunc(keyPressed)
glutTimerFunc(16, update, 0)
glutMainLoop()
glutKeyboardFunc(keyPressed)
glutKeyboardUpFunc(keyReleased)