def restartGame():
    global freeze, game_over, score_display, remaining_health, enemies, score_circles, drone_x, drone_y, game_timer
    freeze = False
    game_over = False
    score_display = 0
    remaining_health = 100
    enemies = []
    score_circles = []
    drone_x = drone_y = 0
    game_timer = 30

def display():
    if is_day:
        glClearColor(1, 1, 1, 1)
    else:
        glClearColor(0, 0, 0, 1)
    glClear(GL_COLOR_BUFFER_BIT)
    drawStars()
    if is_raining:
        drawRain()
    drawEnemies()
    drawScoreCircles()
    drawPlayerDrone()
    drawHealthBar()
    drawScore()
    drawTimer()
    glColor3f(1, 0, 0)
    for bullet in bullets:
        draw_points(bullet[0], bullet[1], 10)
    drawYellowCircle()
    if game_over and remaining_health <= 0:
        drawGameOverMessage()
    if game_over and game_timer <= 0:
        drawWinningMessage()
    glutSwapBuffers()

def keyReleased(key, x, y):
    global key_states
    key_states[key] = False


def update(value):
    global game_timer, game_over, enemy_speed, score_circles, enemies, is_day, is_raining, last_change_time, move_step
    if not freeze and not game_over:
        updateDroneMovement()
        elapsed_time = 30 - game_timer
        if elapsed_time > 5:
            enemy_speed = 5
        if elapsed_time > 10:
            enemy_speed = 10
        if elapsed_time > 15:
            enemy_speed = 13
        if elapsed_time > 20:
            enemy_speed = 16
        if elapsed_time > 20:
            for i, enemy in enumerate(enemies):
                enemy_x, enemy_y = enemy
                dx = drone_x - enemy_x
                dy = drone_y - enemy_y
                distance = (dx ** 2 + dy ** 2) ** 0.5
                if distance > 0:
                    dx /= distance
                    dy /= distance
                    slow_factor = 0.5
                    enemies[i] = (enemy_x + dx * enemy_speed * slow_factor, enemy_y + dy * enemy_speed * slow_factor)
        if elapsed_time > 5 and len(enemies) < MAX_ENEMIES:
            if random.random() < 0.05:
                enemies.append((random.randint(-W_Width // 2, W_Width // 2), W_Height // 2))
        if elapsed_time > 15:
            if random.random() < 0.03:
                score_circles.append((random.randint(-W_Width // 2, W_Width // 2), W_Height // 2))
        if elapsed_time > 5:
            spawnYellowCircle()
        if int(elapsed_time) % 3 == 0 and last_change_time != int(elapsed_time):
            last_change_time = int(elapsed_time)
            is_day = random.choice([True, False])
            is_raining = random.choice([True, False])
        moveEnemies()
        moveScoreCircles()
        moveYellowCircle()
        spawnCircles()
        moveBullets()
        checkBulletCollision()
        checkYellowCircleCollision()
        if score_display >= 40:
            move_step = 13
        if score_display >= 60:
            move_step = 20
        if is_raining:
            updateRain()
        if game_timer > 0:
            game_timer -= 0.016
        else:
            game_over = True
    glutPostRedisplay()
    glutTimerFunc(16, update, 0)