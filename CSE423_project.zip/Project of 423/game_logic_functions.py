def updateRain():
    global rain_drops
    updated_rain_drops = []
    for drop in rain_drops:
        if drop[1] > -W_Height // 2:
            new_drop = (drop[0], drop[1] - 5)
        else:
            new_drop = (random.randint(-W_Width // 2, W_Width // 2), W_Height // 2)
        updated_rain_drops.append(new_drop)
    rain_drops = updated_rain_drops


def moveYellowCircle():
    global yellow_circle
    for i, circle in enumerate(yellow_circle):
        yellow_circle[i] = (circle[0], circle[1] - yellow_circle_speed)
        if circle[1] < -W_Height // 2:
            yellow_circle.pop(i)

def checkYellowCircleCollision():
    global yellow_circle, remaining_health
    for i, circle in enumerate(yellow_circle):
        if hasCollided(drone_x, drone_y, circle[0], circle[1]):
            yellow_circle.pop(i)
            remaining_health = min(100, remaining_health + 20)

def moveEnemies():
    global enemies, remaining_health, game_over
    if freeze or game_over:
        return
    for i, enemy in enumerate(enemies):
        enemies[i] = (enemy[0], enemy[1] - enemy_speed)
        if enemy[1] < -W_Height // 2:
            enemies.pop(i)
        elif hasCollided(drone_x, drone_y, enemy[0], enemy[1]):
            enemies.pop(i)
            remaining_health -= 25
            if remaining_health <= 0:
                game_over = True

def moveScoreCircles():
    global score_circles, score_display
    if freeze or game_over:
        return
    for i, circle in enumerate(score_circles):
        score_circles[i] = (circle[0], circle[1] - enemy_speed)
        if circle[1] < -W_Height // 2:
            score_circles.pop(i)
        elif hasCollided(drone_x, drone_y, circle[0], circle[1]):
            score_circles.pop(i)
            score_display += 10

def hasCollided(x1, y1, x2, y2, radius1=15, radius2=10):
    distance = ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5
    return distance < (radius1 + radius2)

def spawnCircles():
    if random.random() < 0.02:
        enemies.append((random.randint(-W_Width // 2, W_Width // 2), W_Height // 2))
    if random.random() < 0.01:
        score_circles.append((random.randint(-W_Width // 2, W_Width // 2), W_Height // 2))

def spawnYellowCircle():
    global yellow_circle
    if random.random() < 0.01:
        yellow_circle.append((random.randint(-W_Width // 2, W_Width // 2), W_Height // 2))


def moveBullets():
    global bullets
    if game_over:
        return
    updated_bullets = []
    for bullet in bullets:
        new_y = bullet[1] + bullet_speed
        if new_y <= W_Height // 2:
            updated_bullets.append([bullet[0], new_y])
    bullets = updated_bullets
def checkBulletCollision():
    global bullets, enemies
    for bullet in bullets:
        for i, enemy in enumerate(enemies):
            if hasCollided(bullet[0], bullet[1], enemy[0], enemy[1]):
                enemies.pop(i)
                bullets.remove(bullet)
                break

def updateDroneMovement():
    global drone_x, drone_y, move_step, W_Width, W_Height, drone_size
    if game_over:
        return
    if key_states.get(b'a', False):
        drone_x -= move_step
    if key_states.get(b'd', False):
        drone_x += move_step
    if key_states.get(b'w', False):
        drone_y += move_step
    if key_states.get(b's', False):
        drone_y -= move_step
    if drone_x - drone_size < -W_Width // 2:
        drone_x = -W_Width // 2 + drone_size
    if drone_x + drone_size > W_Width // 2:
        drone_x = W_Width // 2 - drone_size
    if drone_y - drone_size < -W_Height // 2:
        drone_y = -W_Height // 2 + drone_size
    if drone_y + drone_size > W_Height // 2:
        drone_y = W_Height // 2 - drone_size