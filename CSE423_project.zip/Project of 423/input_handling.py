
def keyPressed(key, x, y):
    global drone_x, drone_y, freeze, bullets, score_display
    if key == b'r':
        restartGame()
    if game_over:
        return
    if key == b'a':
        drone_x -= move_step
    elif key == b'd':
        drone_x += move_step
    elif key == b'w':
        drone_y += move_step
    elif key == b's':
        drone_y -= move_step
    elif key == b'p':
        freeze = not freeze
    elif key == b' ' and score_display >= 20:
        bullets.append([drone_x, drone_y + 15])



def keyReleased(key, x, y):
    global key_states
    key_states[key] = False